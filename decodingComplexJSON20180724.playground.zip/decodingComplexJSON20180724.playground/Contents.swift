//: Playground 2018.07.24
// JSON is from:
// api.openweathermap.org/data/2.5/weather?lat=35.27709777&lon=-89.9827549&units=imperial&appid=xxx_YOU_NEED_AN_APPID_CODE_xxx
//

import UIKit

struct Sys : Codable {
    var sunrise : Int
    var sunset : Int
}

struct Wind : Codable {
    var speed : Double
    var deg : Int
}

struct CurrentWeather : Codable {
    var temp : Double
    var pressure : Int
    var humidity : Int
    var temp_min : Double
    var temp_max : Double
}

struct Weather : Codable {
    let main : String
    var description : String
}

struct Coord : Codable {
    var lat : Double
    var lon : Double
}

struct Place : Codable {
    var coord : Coord
    var weather : [Weather]
    var main : CurrentWeather
    var wind : Wind
    var sys : Sys
    var name : String
}

let json = """

{"coord":{"lon":-89.98,"lat":35.28},"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01d"}],"base":"stations","main":{"temp":88.16,"pressure":1015,"humidity":55,"temp_min":86,"temp_max":91.4},"visibility":14484,"wind":{"speed":8.05,"deg":330},"clouds":{"all":1},"dt":1532466900,"sys":{"type":1,"id":2508,"message":0.0043,"country":"US","sunrise":1532430210,"sunset":1532480938},"id":4641998,"name":"Millington","cod":200}

""".data(using: .utf8)!

let decoder = JSONDecoder()
let place = try! decoder.decode(Place.self, from: json)

print("01. ",place.coord.lon,"lon")
print("02. ",place.coord.lat,"lat")
print("03. ",place.weather[0].main)
print("04. ",place.weather[0].description)
print("05. ",place.main.temp,"℉ now")
print("06. ",place.main.pressure,"Mb")
print("07. ",place.main.humidity,"%")
print("08. ",place.main.temp_min,"℉ min")
print("09. ",place.main.temp_max,"℉ max")
print("10. ",place.wind.speed,"mph")
print("11. ",place.wind.deg,"°")
print("12. ",place.sys.sunrise,"sunrise")
print("13. ",place.sys.sunset,"sunset")
print("14. ",place.name,"city")
print("\n(Debug output): ")
dump(place)
